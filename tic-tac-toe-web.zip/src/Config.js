module.exports = {
    // API: "https://dqwuzkgzcvs7y.cloudfront.net/api"
    API: "http://localhost:3001/api"
}