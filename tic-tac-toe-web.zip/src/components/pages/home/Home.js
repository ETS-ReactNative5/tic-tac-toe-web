
import React, { Component,useState,useEffect } from 'react';
import Header from '../Header';

const Home = () => {
  
    return(
        <div>
          <Header />
           <div className="banner-sec">
               <div className="banner-content">
                   <h3>tic tac toe</h3>
               </div>
           </div>
           
        </div>
    )
}

export default Home;