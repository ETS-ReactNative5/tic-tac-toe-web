import React, {useEffect,useRef,useState} from "react";
import Plot from 'react-plotly.js';
import MaterialTable from "material-table";
import Header from "../Header";
import { API } from "../../../Config";


const Dashboard = ()=>{
    const [namelist, setNamelist] = useState([]);
    const [data, setData] = useState([]);

 
  
    useEffect(() => {
        ShowHistory();
        getUserlistByid();

        

    }, []);

    const getUserlistByid = () => {
        const id = JSON.parse(localStorage.getItem('users')).id;

        fetch(API+"/user/list/by/" + id,
            {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',

                },
            }
        ).then((response) => {
            if (response.status == 200) {
                response.json().then((resp) => {
                    console.warn("result", resp);
                    setNamelist(resp.data[0]);
                   
                });
            }
            


        })
    }
    

    const ShowHistory = () => {
 
        const name = JSON.parse(localStorage.getItem('users')).name;
        const uid = JSON.parse(localStorage.getItem('users')).id;
        console.log(name)
      
        fetch(API+"/history/list/" + uid,
            {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',

                },
            }
        ).then((response) => {
            if (response.status == 200) {
                response.json().then((resp) => {
                    console.warn("result", resp);
                    let _temp = [];
                    resp.data.map((v, i) => {
                        _temp.push({
                            username: v.name,
                            email: v.email,
                            Date: new Date(v.date).toLocaleString(),
                            Result: v.result,
                         
                        })
                    })
                    setData(_temp);


                });
            }
            


        })
    }

    return(
        <div className="recordlist-bg">
            <Header />
            <div className="container">
                <div className="heading-dashboard">
                    {
                        <h3>Welcome {namelist.name},</h3>
                    }
                </div>
                <div className="row">
                    <div className="col-lg-6">
                    <div className="chart-box">
                        <Plot style={{width: "100%", height: "240px"}}
                            data={[
                            {
                                x: [1, 2, 3,4,5,6,7,8],
                                y: [2, 5, 3,7,4,1,8],
                                type: 'scatter',
                                mode: 'lines+markers',
                                marker: {color: 'red'},
                            },
                            {type: 'bar', x: [1, 2, 3,4,5,6,7,8], y: [2, 5, 3,7,4,1,8]},
                            ]}
                            layout={ { 
                            showlegend: false,
                            margin: {
                                l: 0,
                                r: 30,
                                b: 20,
                                t: 10,
                                pad: 4
                            },} }
                        />
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="chart-box">
                        <Plot style={{width: "100%", height: "240px"}}
                            data={[
                            {
                                x: [1, 2, 3],
                                y: [2, 6, 3],
                                type: 'scatter',
                                mode: 'lines+markers',
                                marker: {color: 'red'},
                            },
                            {type: 'line', x: [1, 2, 3], y: [2, 5, 3]},
                            ]}
                            layout={ { 
                            showlegend: false,
                            margin: {
                                l: 30,
                                r: 0,
                                b: 20,
                                t: 10,
                                pad: 4
                            },} }
                        />
                        </div>
                    </div>
                </div>
            </div>
            <div className="container">
            <div className="table-box">
            <div style={{ maxWidth: "100%" }} className="table-box">
                        <MaterialTable options={{
                                    headerStyle:{backgroundColor:'#000',color:'#fff'},
                                    search: false,
                                    showTitle: false,
                                    toolbar:false,
                            }}
                            columns={[
                               
                                { title: "User name", field: "username" },
                                { title: "Date", field: "Date" },
                                { title: "Email", field: "email" },
                                { title: "Result", field: "Result" },
                                
                                
                               
                            ]}
                            data={data}
                           
                        />
                    </div>
            </div>
            </div>
        </div>
    )

}

export default Dashboard;