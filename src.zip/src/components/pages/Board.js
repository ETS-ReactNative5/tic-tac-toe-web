function Board(props) {
  return (
    <div className="board" {...props} />
  );
}

export default Board;